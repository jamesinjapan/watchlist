$(document).ready(function() {
  $('.search-title').matchHeight({
    byRow: false,
    property: 'height',
    target: null,
    remove: false
  });
});
